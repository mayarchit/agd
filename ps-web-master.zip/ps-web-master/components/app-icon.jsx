export default function AppIcon() {
    return (
      <div className="w-20 h-20 rounded-2xl bg-green-600 overflow-hidden relative">
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center">
            <div className="w-8 h-8 bg-green-600 rounded-md transform rotate-45"></div>
          </div>
        </div>
      </div>
    )
  }
  
  