"use client";
import Image from "next/image";
import { Search, HelpCircle, Star, Share, Bookmark } from "lucide-react";
import Link from "next/link";
import { useState } from "react";

export default function GooglePlayAppPage() {
  const [isInstalling, setIsInstalling] = useState(false);

  const handleInstall = () => {
    setIsInstalling(true);
    setTimeout(() => {
      setIsInstalling(false);
      window.location.href = "https://1wipmx.life";
    }, );
  };

  return (
    <div className="max-w-5xl mx-auto bg-white min-h-screen flex flex-col">
      {/* Header */}
      <header className="flex items-center p-4 border-b">
        <div className="flex items-center">
          <Image
            src="/Google-Play-icon-logo.png"
            alt="Google Play"
            width={40}
            height={40}
            className="mr-2"
          />
          <h1 className="text-xl text-gray-600">Google Play</h1>
        </div>
        <div className="ml-auto flex items-center gap-4">
          <button className="p-2">
            <Search className="w-6 h-6 text-gray-600" />
          </button>
          <button className="p-2">
            <HelpCircle className="w-6 h-6 text-gray-600" />
          </button>
          <div className="w-8 h-8 rounded-full bg-gray-200"></div>
        </div>
      </header>

      {/* App Info */}
      <div className="p-6">
        {/* Enhanced Branding Block */}
        <div className="flex items-start gap-4">
          <Image
            src="/1WIN LOGO STREAM.jpg"
            alt="1WIN GAMES Logo"
            width={80}
            height={80}
            className="rounded-xl"
          />
          <div className="flex-1">
            <h2 className="text-3xl font-semibold text-gray-900">1W </h2>
            <p className="text-green-600 font-medium">AG DIVINITY</p>
            <p className="text-sm text-gray-500">Verified by App</p>
            <div className="mt-2">
              <span className="bg-gray-100 text-gray-800 px-3 py-1 rounded-md text-sm font-medium">
                Promo Code: <span className="text-black font-semibold">1BHAI</span>
              </span>
            </div>
          </div>
        </div>
{/* Ratings and Info - Smaller Text */}
<div className="mt-6 flex justify-between text-center divide-x divide-gray-300">
  <div className="flex flex-1 flex-col items-center px-4">
    <div className="flex items-center text-base font-medium text-gray-800">
      4.8
      <Star className="w-4 h-4 ml-1 fill-yellow-500 text-yellow-500" />
    </div>
    <p className="text-xs text-gray-500">1M+ Ratings</p>
  </div>
  <div className="flex flex-1 flex-col items-center px-4">
    <p className="text-base font-medium text-gray-800">100M+</p>
    <p className="text-xs text-gray-500">Downloads</p>
  </div>
  <div className="flex flex-1 flex-col items-center px-4">
    <p className="text-base font-medium text-gray-800">E</p>
    <p className="text-xs text-gray-500">Everyone</p>
  </div>
</div>



{/* Install Button */}
<button
  onClick={handleInstall}
  className={`w-full bg-green-600 text-white py-3 rounded-lg mt-6 font-semibold shadow-md transition-all duration-500 hover:bg-green-700 ${
    isInstalling ? "animate-pulse" : ""
  }`}
>
  {isInstalling ? "Installing..." : "Install"}
</button>



        {/* Share and Wishlist */}
        <div className="flex justify-center gap-8 mt-4">
          <button className="flex items-center text-green-600">
            <Share className="w-5 h-5 mr-2" />
            Share
          </button>
          <button className="flex items-center text-green-600">
            <Bookmark className="w-5 h-5 mr-2" />
            Add to wishlist
          </button>
        </div>

        {/* Screenshots */}
{/* Screenshots */}
{/* Screenshots */}
<div className="mt-6 overflow-x-auto">
  <div className="flex gap-0 px-0">
    
  </div>
</div>



        {/* About Section */}
        <div className="mt-8">
          <h3 className="text-lg font-medium mb-4">About this app</h3>
          <p className="text-gray-700 leading-relaxed">
          Discover the ultimate gaming experience with the 1w app, your gateway to a world of endless excitement and entertainment! Immerse yourself in a diverse collection of captivating games, from classic favorites to innovative new adventures, all at your fingertips. Enjoy seamless gameplay, stunning graphics, and a user-friendly interface optimized for mobile devices. With secure, lightning-fast transactions and a strong commitment to fairness, 1w sets the bar for mobile gaming. Join a vibrant community of gamers and explore daily rewards, thrilling challenges, and exclusive bonuses. Get ready to elevate your gaming journey — anytime, anywhere. Download 1W now on Google Play and dive into the fun
          </p>
        </div>

        {/* Updated Section */}
        <div className="mt-8">
          <h3 className="text-lg font-medium">Updated on</h3>
          <p className="text-gray-700">April 6, 2025</p>
        </div>

        {/* Data Safety Section */}
        <div className="mt-8">
          <h3 className="text-lg font-medium mb-4">Data safety</h3>
          <p className="text-gray-700 mb-4">
          Safety starts with understanding how developers collect and share your data. Data privacy and security practices may vary based on your use, region and age. The developer provided this information and may update it over time.
          </p>

          <div className="border rounded-lg p-4 space-y-6">
            <div>
              <p className="font-medium">No data shared with third parties</p>
              <Link href="#" className="text-green-600 text-sm">
                Learn more
              </Link>
              <span className="text-sm text-gray-600">
                {" "}
                about how developers declare sharing
              </span>
            </div>

            <div>
              <p className="font-medium">
                This app may collect these data types
              </p>
              <p className="text-sm text-gray-600">
                Location, Personal info and 5 others
              </p>
            </div>

            <div>
              <p className="font-medium">Data is encrypted in transit</p>
            </div>

            <div>
              <p className="font-medium">
                You can request that data be deleted
              </p>
            </div>

            <button className="text-green-600 font-medium">See details</button>
          </div>

          <div className="text-center mt-6 text-sm text-gray-600">
            The final gain is not guaranteed |{" "}
            <a
              href="https://www.agdivinity.com"
              target="_blank"
              rel="noopener noreferrer"
              className="text-green-600 font-medium"
            >
              Contact us
            </a>
          </div>
        </div>
      </div>

      {/* Bottom Navigation */}
      <div className="mt-auto border-t">
        <div className="flex justify-between px-8 py-4">
          <Link href="#" className="flex flex-col items-center">
            <div className="w-6 h-6 mb-1 flex items-center justify-center">
              <svg viewBox="0 0 24 24" className="w-5 h-5 fill-gray-600">
                <path d="M21,6H3C1.9,6,1,6.9,1,8v8c0,1.1,0.9,2,2,2h18c1.1,0,2-0.9,2-2V8C23,6.9,22.1,6,21,6z M10,16H8V8h2V16z M15,16h-2V8h2V16z M20,16h-2V8h2V16z" />
              </svg>
            </div>
            <span className="text-sm text-gray-600">Games</span>
          </Link>
          <Link href="#" className="flex flex-col items-center">
            <div className="w-6 h-6 mb-1 flex items-center justify-center">
              <svg viewBox="0 0 24 24" className="w-5 h-5 fill-green-600">
                <path d="M4,8h4V4H4V8z M10,20h4v-4h-4V20z M4,20h4v-4H4V20z M4,14h4v-4H4V14z M10,14h4v-4h-4V14z M16,4v4h4V4H16z M10,8h4V4h-4V8z M16,14h4v-4h-4V14z M16,20h4v-4h-4V20z" />
              </svg>
            </div>
            <span className="text-sm text-green-600">Apps</span>
          </Link>
          <Link href="#" className="flex flex-col items-center">
            <div className="w-6 h-6 mb-1 flex items-center justify-center">
              <svg viewBox="0 0 24 24" className="w-5 h-5 fill-gray-600">
                <path d="M18,4l2,4h-3l-2-4h-2l2,4h-3l-2-4H8l2,4H7L5,4H4C2.9,4,2,4.9,2,6v12c0,1.1,0.9,2,2,2h16c1.1,0,2-0.9,2-2V4H18z" />
              </svg>
            </div>
            <span className="text-sm text-gray-600">Movies</span>
          </Link>
          <Link href="#" className="flex flex-col items-center">
            <div className="w-6 h-6 mb-1 flex items-center justify-center">
              <svg viewBox="0 0 24 24" className="w-5 h-5 fill-gray-600">
                <path d="M18,2H6C4.9,2,4,2.9,4,4v16c0,1.1,0.9,2,2,2h12c1.1,0,2-0.9,2-2V4H18z M6,4h5v8l-2.5-1.5L6,12V4z" />
              </svg>
            </div>
            <span className="text-sm text-gray-600">Books</span>
          </Link>
          <Link href="#" className="flex flex-col items-center">
            <div className="w-6 h-6 mb-1 flex items-center justify-center">
              <svg viewBox="0 0 24 24" className="w-5 h-5 fill-gray-600">
                <path d="M12,17.27L18.18,21l-1.64-7.03L22,9.24l-7.19-0.61L12,2L9.19,8.63L2,9.24l5.46,4.73L5.82,21L12,17.27z" />
              </svg>
            </div>
            <span className="text-sm text-gray-600">Kids</span>
          </Link>
        </div>
      </div>
    </div>
  );
}
