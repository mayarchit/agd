import Image from "next/image";
import { Search, HelpCircle, Star, Share, Bookmark } from "lucide-react";
import Link from "next/link";

export default function GooglePlayAppPage() {
  return (
    <div className="max-w-5xl mx-auto bg-white min-h-screen flex flex-col">
      {/* Header */}
      <header className="flex items-center p-4 border-b">
        <div className="flex items-center">
          <Image
            src="/Google-Play-icon-logo.png"
            alt="Google Play"
            width={40}
            height={40}
            className="mr-2"
          />
          <h1 className="text-xl text-gray-600">Google Play</h1>
        </div>
        <div className="ml-auto flex items-center gap-4">
          <button className="p-2">
            <Search className="w-6 h-6 text-gray-600" />
          </button>
          <button className="p-2">
            <HelpCircle className="w-6 h-6 text-gray-600" />
          </button>
          <div className="w-8 h-8 rounded-full bg-gray-200"></div>
        </div>
      </header>

      {/* App Info */}
      <div className="p-6">
        <div className="flex gap-4">
          <div className="flex-shrink-0">
            {/* <Image
              // src="https://cdn.legit.ng/images/720/b38aa5e59e11625e.webp?v=1"
              alt="App Icon"
              width={80}
              height={80}
              className="rounded-2xl"
            /> */}
          </div>
          <div className="flex-1">
            <h2 className="text-2xl font-medium">1X GAMES</h2>
            <p className="text-green-600">AG DIVINITY</p>
          </div>
        </div>

        {/* Ratings and Info */}
        <div className="flex justify-between mt-8">
          <div className="text-center">
            <div className="flex items-center justify-center">
              <span className="text-xl font-medium">4.8</span>
              <Star className="w-5 h-5 ml-1 fill-gray-700 text-gray-700" />
            </div>
            <p className="text-sm text-gray-600">1M+ Downloads</p>
          </div>
          <div className="text-center">
            <p className="text-xl font-medium">E</p>
            <p className="text-sm text-gray-600">Everyone</p>
          </div>
        </div>

        {/* Install Button */}
        <button className="w-full bg-green-600 text-white py-3 rounded-md mt-6 font-medium">
          Install
        </button>

        {/* Share and Wishlist */}
        <div className="flex justify-center gap-8 mt-4">
          <button className="flex items-center text-green-600">
            <Share className="w-5 h-5 mr-2" />
            Share
          </button>
          <button className="flex items-center text-green-600">
            <Bookmark className="w-5 h-5 mr-2" />
            Add to wishlist
          </button>
        </div>

        {/* Screenshots */}
        <div className="mt-8 overflow-x-auto flex gap-4">
          {/* <Image
            src="https://1xbet-aviator.org/wp-content/uploads/2024/01/app-header.webp"
            alt="Screenshot 1"
            width={200}
            height={400}
            className="rounded-lg"
          /> */}
          {/* <Image
            src="https://via.placeholder.com/200x400"
            alt="Screenshot 2"
            width={200}
            height={400}
            className="rounded-lg"
          />
          <Image
            src="https://via.placeholder.com/200x400"
            alt="Screenshot 3"
            width={200}
            height={400}
            className="rounded-lg"
          /> */}
        </div>

        {/* About Section */}
        <div className="mt-8">
          <h3 className="text-lg font-medium mb-4">About this app</h3>
          <p className="text-gray-700 leading-relaxed">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis nec
            turpis at sapien pretium varius. Donec iaculis orci in commodo
            blandit. Sed a mattis lorem.
          </p>
        </div>

        {/* Bottom Note */}
        <div className="text-center mt-6 text-sm text-gray-600">
          The final gain is not guaranteed |{" "}
          <Link href="#" className="text-gray-600">
            Contact us
          </Link>
        </div>
      </div>
    </div>
  );
}
